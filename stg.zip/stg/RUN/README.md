![](SabreLogo.jpeg)
# ⚔️ SABRE ⚔️
## Security Automation Batch Runtime Engine
> Logo generated via Bing Image Creator/Dall-e 

## 📣 Introduction 
SABRE is a security automation engine to facilitate automated scanning of M&G infrastructure.

It uses its own infrastructure to run scripts and utilities in a secure manner, using passwordless authentication to authenticate to target systems.

Azure DevOps pipelines are used to orchestrate calls to SABRE to instruct it to run required automation scripts.

## SABRE-RUN REPO
This repository hosts the scripts and pipelines to have SABRE run automation scripts. 

The `SABRE-BUILD` repository hosts the code/pipelines that builds the SABRE infrastructure, the code for the SABRE service, and the code to install SABRE on the SABRE server(s).

## ⚠️ Ownership
SABRE is owned and supported by Security Engineering