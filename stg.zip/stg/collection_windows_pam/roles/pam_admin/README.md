ent.windows_pam.windows_pam_admin
=========
Ansible Role for configuring local admins on a windows server.

Requirements
------------
None

Role Variables
--------------
None

Dependencies
------------
None

Example Playbook
----------------
    - hosts: windows
      roles:
         - ent.windows_pam.windows_pam_admin

License
-------


Author Information
------------------
rob.slater@mandg.com
graham.gold@mandg.com