Param
(
    [Parameter(Mandatory = $true)]
    [String] $searchUser
)
$mgSID      =  (Get-ADDomain -server 1.co.uk).DomainSID.Value
$prodSID    =  (Get-ADDomain -server 1.local).DomainSID.Value
$corpSID    =  (Get-ADDomain -server 1.local).DomainSID.Value
$pgdsSID    =  (Get-ADDomain -server 1.local).DomainSID.Value
$corpTenant = ""

try { 
    $ADTenant = Get-AzureADTenantDetail 
} 
catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] { 
    Write-Host "You're not connected to AzureAD, authenticating..."; 
    Connect-AzureAD -TenantID $corpTenant -Verbose;
}

$userSID = (Get-AzureADUser -SearchString $searchUser).OnPremisesSecurityIdentifier
If ($userSID.Length -gt 0){
    switch -wildcard ($userSID) {
        "$corpSID*"     { return "[INFO] User $searchuser Primary Domain is 1.LOCAL" }
        "$prodSID*"     { return "[INFO] User $searchuser Primary Domain is 1.LOCAL" }
        "$mgSID*"       { return "[INFO] User $searchuser Primary Domain is 1.CO.UK" }
        "$pgdsSID*"     { return "[INFO] User $searchuser Primary Domain is 1.LOCAL" }
        Default         { return "[ERROR] User SID $userSID not found in the domains 1.LOCAL, 1.LOCAL, 1.CO.UK or 1.LOCAL" }
    }
} else {
    return "[ERROR] User $searchUser not found in AzureAD in Tenant: $($ADTenant.DisplayName)"
}